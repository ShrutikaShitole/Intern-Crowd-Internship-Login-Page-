# Interncrowd_intS8CALern_task2
I developed landing page using HTML, CSS and Javascript. Intern Crowd LLP first task.
